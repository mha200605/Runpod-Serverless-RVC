"""Offline unit tests (no GPU, no Applio, no internet). Run:  python -m unittest discover -s tests -v"""
import base64
import http.server
import os
import sys
import tempfile
import threading
import unittest
import wave
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import schemas  # noqa: E402
from config import MB, Settings, load_settings  # noqa: E402
from model_store import ModelNotFound, ModelStore  # noqa: E402
from security import (DownloadError, ValidationError, assert_public_http_url,  # noqa: E402
                      download_to_file, redact_url, sanitize_model_id)
from service import Service, make_downloader  # noqa: E402
from sinks import Base64Sink, SinkError, s3_configured, select_sink  # noqa: E402

PTH = b"PK\x03\x04" + b"\x00" * 4000
INDEX = b"FAISSINDEX" * 200
HITS = {}


class _H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        HITS[self.path] = HITS.get(self.path, 0) + 1
        routes = {"/m.pth": PTH, "/m.index": INDEX, "/big": b"x" * (3 * MB),
                  "/html": b"<!DOCTYPE html><html>share page</html>" + b" " * 2000}
        if self.path == "/redir":
            self.send_response(302); self.send_header("Location", "/m.pth"); self.end_headers(); return
        if self.path not in routes:
            self.send_response(404); self.end_headers(); return
        body = routes[self.path]
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass  # client hung up (expected in the size-limit test)


def _wav_bytes(seconds=0.2, sr=16000):
    with tempfile.NamedTemporaryFile(suffix=".bin") as f:
        with wave.open(f.name, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
            w.writeframes(b"\x00\x00" * int(sr * seconds))
        return Path(f.name).read_bytes()


class FakeEngine:
    def __init__(self):
        self.calls = []

    def convert(self, *, input_path, output_dir, pth, index, req):
        self.calls.append({"index": index, "req": req, "input_exists": Path(input_path).is_file()})
        out = Path(output_dir) / f"out.{req.export_format.lower()}"
        out.write_bytes(_wav_bytes())
        return SimpleNamespace(path=out, sample_rate=16000, duration_s=0.2, device="cpu", model_version="v2")


def make_settings(models_dir, **over):
    base = dict(applio_dir=Path("/nonexistent"), models_dir=Path(models_dir), storage_mode="ephemeral",
                max_audio_bytes=10 * MB, max_pth_bytes=2 * MB, max_index_bytes=2 * MB, download_timeout_s=10,
                max_inline_output_bytes=7 * MB, allow_private_urls=True, allowed_url_hosts=(),
                default_return_mode="auto", allowed_f0_methods=("rmvpe",), s3_presign_ttl_s=3600)
    base.update(over)
    return Settings(**base)


class ServerCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _H)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def setUp(self):
        HITS.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)


class TestSecurity(unittest.TestCase):
    def test_model_ids(self):
        for ok in ("voice1", "My_Voice-2", "a" * 64):
            self.assertEqual(sanitize_model_id(ok), ok)
        for bad in ("", "../etc", "a/b", "-x", "a" * 65, "my.voice", "x y", None, 5,
                    "trained_voice", "my_Trained_v2"):
            with self.assertRaises(ValidationError, msg=repr(bad)):
                sanitize_model_id(bad)

    def test_blocked_urls(self):
        for url in ("http://127.0.0.1/x", "http://10.0.0.5/x", "http://169.254.169.254/latest",
                    "http://192.168.1.1/", "http://[::1]/x", "http://0.0.0.0/", "http://[::ffff:127.0.0.1]/"):
            with self.assertRaises(ValidationError, msg=url):
                assert_public_http_url(url)
        for url in ("ftp://example.com/x", "file:///etc/passwd", "http:///x", "", "javascript:1"):
            with self.assertRaises(ValidationError, msg=url):
                assert_public_http_url(url)

    def test_allowed_urls(self):
        self.assertEqual(assert_public_http_url("https://8.8.8.8/x.pth"), "https://8.8.8.8/x.pth")
        assert_public_http_url("http://127.0.0.1/x", allow_private=True)
        with self.assertRaises(ValidationError):
            assert_public_http_url("https://8.8.8.8/x", allowed_hosts=["huggingface.co"])

    def test_redact(self):
        self.assertEqual(redact_url("https://u:p@h.example/a/b.pth?X-Sig=secret#f"), "https://h.example/a/b.pth")


class TestDownload(ServerCase):
    def test_ok_and_sha(self):
        d = Path(self.tmp.name) / "f.pth"
        info = download_to_file(self.base + "/m.pth", d, max_bytes=MB, allow_private=True)
        self.assertEqual(info["bytes"], len(PTH)); self.assertTrue(d.is_file())
        self.assertFalse(Path(str(d) + ".part").exists())

    def test_redirect(self):
        d = Path(self.tmp.name) / "f.pth"
        download_to_file(self.base + "/redir", d, max_bytes=MB, allow_private=True)
        self.assertEqual(d.read_bytes(), PTH)

    def test_size_limit_and_cleanup(self):
        d = Path(self.tmp.name) / "big.bin"
        with self.assertRaises(DownloadError):
            download_to_file(self.base + "/big", d, max_bytes=MB, allow_private=True)
        self.assertFalse(d.exists()); self.assertFalse(Path(str(d) + ".part").exists())

    def test_404(self):
        with self.assertRaises(DownloadError):
            download_to_file(self.base + "/nope", Path(self.tmp.name) / "x", max_bytes=MB, allow_private=True)

    def test_ssrf_blocked_by_default(self):
        with self.assertRaises(ValidationError):
            download_to_file(self.base + "/m.pth", Path(self.tmp.name) / "x", max_bytes=MB)


class TestSchemas(unittest.TestCase):
    S = make_settings("/tmp/x")

    def test_defaults(self):
        r = schemas.parse_convert({"model_id": "v1", "audio_url": "https://a/b.wav"}, self.S)
        self.assertEqual((r.pitch, r.f0_method, r.index_rate, r.protect, r.export_format, r.return_mode),
                         (0, "rmvpe", 0.75, 0.33, "WAV", "auto"))

    def test_rejections(self):
        base = {"model_id": "v1", "audio_url": "https://a/b.wav"}
        bad = [
            {**base, "index_rat": 0.5},                # typo -> unknown field
            {**base, "pitch": 25}, {**base, "pitch": 1.5}, {**base, "pitch": True},
            {**base, "index_rate": 1.1}, {**base, "protect": 0.6},
            {**base, "f0_method": "crepe"},            # not enabled by default
            {**base, "export_format": "M4A"},
            {**base, "audio_b64": "AAAA"},             # both sources
            {"model_id": "v1"},                        # no source
            {"audio_url": "https://a/b.wav"},          # no model
            {**base, "pth_url": "ftp://x/y.pth"},
            {**base, "f0_autotune": "yes"},
        ]
        for raw in bad:
            with self.assertRaises(ValidationError, msg=str(raw)):
                schemas.parse_convert(raw, self.S)

    def test_normalisation(self):
        r = schemas.parse_convert({"model_id": "v1", "audio_b64": "AAAA", "export_format": "mp3",
                                   "f0_method": "RMVPE", "audio_filename": "My Song.MP3"}, self.S)
        self.assertEqual((r.export_format, r.f0_method, r.audio_filename), ("MP3", "rmvpe", "input.mp3"))

    def test_action(self):
        self.assertEqual(schemas.parse_action({}), "convert")
        with self.assertRaises(ValidationError):
            schemas.parse_action({"action": "rm -rf"})
        with self.assertRaises(ValidationError):
            schemas.parse_action("hello")


class TestModelStore(ServerCase):
    def store(self):
        calls = []

        def dl(url, dest, max_bytes):
            calls.append(url)
            return download_to_file(url, dest, max_bytes=max_bytes, allow_private=True)
        return ModelStore(Path(self.tmp.name) / "models", dl, max_pth_bytes=2 * MB, max_index_bytes=2 * MB), calls

    def test_register_ensure_list_delete(self):
        st, calls = self.store()
        paths, now = st.register("alice", self.base + "/m.pth", self.base + "/m.index")
        self.assertTrue(now); self.assertIsNotNone(paths.index)
        self.assertEqual(paths.meta["pth"]["source"], self.base + "/m.pth")
        p2, now2 = st.ensure("alice", self.base + "/m.pth", self.base + "/m.index")
        self.assertFalse(now2); self.assertEqual(len(calls), 2)          # nothing re-downloaded
        self.assertEqual([m["model_id"] for m in st.list()], ["alice"])
        self.assertTrue(st.delete("alice")); self.assertFalse(st.delete("alice"))
        with self.assertRaises(ModelNotFound):
            st.get("alice")

    def test_no_index_and_overwrite(self):
        st, calls = self.store()
        p, _ = st.register("bob", self.base + "/m.pth")
        self.assertIsNone(p.index)
        p, now = st.register("bob", self.base + "/m.pth", self.base + "/m.index", overwrite=True)
        self.assertTrue(now); self.assertIsNotNone(p.index)
        self.assertFalse(any(Path(st.root / ".trash").glob("*")) if (st.root / ".trash").exists() else False)

    def test_bad_downloads_leave_nothing_behind(self):
        st, _ = self.store()
        for url in ("/html", "/nope"):
            with self.assertRaises(DownloadError):
                st.register("carol", self.base + url)
        with self.assertRaises(DownloadError):                      # index is an HTML page
            st.register("carol", self.base + "/m.pth", self.base + "/html")
        self.assertEqual(st.list(), []); self.assertFalse(st.exists("carol"))
        self.assertEqual(list((st.root / ".staging").glob("*")), [])

    def test_missing_model_message(self):
        st, _ = self.store()
        with self.assertRaises(ModelNotFound):
            st.ensure("ghost", None, None)

    def test_trained_in_root_rejected(self):
        with self.assertRaises(ValidationError):
            ModelStore(Path(self.tmp.name) / "trained_models", lambda *a: {}, max_pth_bytes=1, max_index_bytes=1)


class TestSinks(unittest.TestCase):
    def test_base64(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "o.wav"; f.write_bytes(b"abc")
            out = Base64Sink(100).publish(f, "WAV")
            self.assertEqual(base64.b64decode(out["audio_b64"]), b"abc")
            self.assertIsNone(out["audio_url"])
            with self.assertRaises(SinkError):
                Base64Sink(2).publish(f, "WAV")

    def test_selection(self):
        s = make_settings("/tmp/x")
        self.assertIsInstance(select_sink("auto", s, {}), Base64Sink)
        with self.assertRaises(SinkError):
            select_sink("url", s, {})
        self.assertFalse(s3_configured({"S3_BUCKET": "b"}))
        self.assertTrue(s3_configured({"S3_BUCKET": "b", "S3_ACCESS_KEY_ID": "k", "S3_SECRET_ACCESS_KEY": "s"}))


class TestService(ServerCase):
    def svc(self, **over):
        s = make_settings(Path(self.tmp.name) / "m", **over)
        st = ModelStore(s.models_dir, make_downloader(s),
                        max_pth_bytes=s.max_pth_bytes, max_index_bytes=s.max_index_bytes)
        eng = FakeEngine()
        return Service(s, st, lambda: eng), eng

    def job(self, **kw):
        return {"model_id": "alice", "audio_b64": base64.b64encode(_wav_bytes()).decode(),
                "pth_url": self.base + "/m.pth", "index_url": self.base + "/m.index", **kw}

    def test_convert_roundtrip_and_cache(self):
        svc, eng = self.svc()
        r1 = svc.handle(self.job(pitch=3, index_rate=0.5))
        self.assertEqual(r1["status"], "ok", r1)
        self.assertEqual(r1["delivery"], "base64"); self.assertTrue(r1["model"]["registered_now"])
        self.assertTrue(r1["worker"]["cold_start"]); self.assertEqual(r1["audio_format"], "wav")
        self.assertEqual(base64.b64decode(r1["audio_b64"])[:4], b"RIFF")
        self.assertEqual(eng.calls[0]["req"].pitch, 3)
        r2 = svc.handle({"model_id": "alice", "audio_b64": self.job()["audio_b64"]})   # no URLs this time
        self.assertEqual(r2["status"], "ok"); self.assertFalse(r2["model"]["registered_now"])
        self.assertFalse(r2["worker"]["cold_start"])
        self.assertEqual((HITS["/m.pth"], HITS["/m.index"]), (1, 1))                    # cached
        self.assertEqual(list(Path(tempfile.gettempdir()).glob("rvcjob_*")), [])        # workdir cleaned

    def test_audio_url_input(self):
        svc, _ = self.svc()
        raw = self.job(); del raw["audio_b64"]; raw["audio_url"] = self.base + "/m.pth"
        self.assertEqual(svc.handle(raw)["status"], "ok")

    def test_no_index_warns(self):
        svc, eng = self.svc()
        raw = self.job(); del raw["index_url"]
        r = svc.handle(raw)
        self.assertEqual(r["status"], "ok"); self.assertFalse(r["model"]["index_used"])
        self.assertTrue(r["warnings"]); self.assertIsNone(eng.calls[0]["index"])

    def test_errors_are_structured(self):
        svc, _ = self.svc()
        cases = [
            ({"model_id": "ghost", "audio_b64": "AAAA"}, "MODEL_NOT_FOUND"),
            (self.job(pitch=99), "INVALID_INPUT"),
            (self.job(audio_b64="!!notbase64!!"), "INVALID_INPUT"),
            (self.job(model_id="erin", pth_url=self.base + "/html"), "DOWNLOAD_FAILED"),
            (self.job(return_mode="url"), "OUTPUT_FAILED"),
            ("not a dict", "INVALID_INPUT"),
            ({"action": "bogus"}, "INVALID_INPUT"),
        ]
        for raw, code in cases:
            r = svc.handle(raw)
            self.assertEqual(r.get("error_code"), code, (raw, r))
            self.assertTrue(r["error"].startswith(code))

    def test_ssrf_default_blocks_local_urls(self):
        svc, _ = self.svc(allow_private_urls=False)
        r = svc.handle(self.job())
        self.assertEqual(r["error_code"], "INVALID_INPUT")

    def test_admin_actions(self):
        svc, _ = self.svc()
        reg = svc.handle({"action": "register_model", "model_id": "dave", "pth_url": self.base + "/m.pth"})
        self.assertTrue(reg["registered_now"])
        again = svc.handle({"action": "register_model", "model_id": "dave", "pth_url": self.base + "/m.pth"})
        self.assertTrue(again["already_present"])
        self.assertEqual([m["model_id"] for m in svc.handle({"action": "list_models"})["models"]], ["dave"])
        self.assertTrue(svc.handle({"action": "delete_model", "model_id": "dave"})["deleted"])
        ping = svc.handle({"action": "ping"})
        self.assertEqual(ping["status"], "ok"); self.assertFalse(ping["engine_loaded"])

    def test_inline_limit(self):
        svc, _ = self.svc(max_inline_output_bytes=10)
        r = svc.handle(self.job())
        self.assertEqual(r["error_code"], "OUTPUT_FAILED"); self.assertIn("inline limit", r["error"])


class TestConfig(unittest.TestCase):
    def test_storage_mode(self):
        with tempfile.TemporaryDirectory() as d:
            s = load_settings({"RUNPOD_VOLUME_PATH": d})
            self.assertEqual((s.storage_mode, s.models_dir), ("network-volume", Path(d) / "rvc" / "models"))
        s = load_settings({"RUNPOD_VOLUME_PATH": "/definitely/not/here"})
        self.assertEqual(s.storage_mode, "ephemeral")
        self.assertEqual(load_settings({"RVC_MODELS_DIR": "/x/y"}).storage_mode, "explicit")
        with self.assertRaises(ValueError):
            load_settings({"DEFAULT_RETURN_MODE": "carrier-pigeon"})


if __name__ == "__main__":
    unittest.main()
