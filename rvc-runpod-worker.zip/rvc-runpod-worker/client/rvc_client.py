#!/usr/bin/env python3
"""Client + CLI for the RVC RunPod Serverless endpoint.

The API key is read from the RUNPOD_API_KEY environment variable (never hard-code it).

Python:
    from rvc_client import RvcClient
    c = RvcClient("YOUR_ENDPOINT_ID")
    c.register_model("my_voice", "https://host/my_voice.pth", "https://host/my_voice.index")
    result = c.convert(model_id="my_voice", audio_path="in.wav", out_path="out.wav", pitch=0, index_rate=0.75)

CLI:
    python rvc_client.py --endpoint ID ping
    python rvc_client.py --endpoint ID register my_voice --pth-url URL [--index-url URL]
    python rvc_client.py --endpoint ID convert my_voice in.wav out.wav [--pitch 2] [--index-rate 0.7]
    python rvc_client.py --endpoint ID list
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import requests

API_BASE = "https://api.runpod.ai/v2"
_PENDING = {"IN_QUEUE", "IN_PROGRESS"}


class RvcError(RuntimeError):
    pass


class RvcClient:
    def __init__(self, endpoint_id: str, api_key: Optional[str] = None, *, timeout_s: int = 600,
                 poll_interval_s: float = 2.0):
        self.endpoint_id = endpoint_id
        self.api_key = api_key or os.environ.get("RUNPOD_API_KEY")
        if not self.api_key:
            raise RvcError("Set the RUNPOD_API_KEY environment variable (or pass api_key=).")
        self.timeout_s = timeout_s
        self.poll_interval_s = poll_interval_s
        self._http = requests.Session()
        self._http.headers.update({"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"})

    # ---- low level ---------------------------------------------------------------------
    def _url(self, path: str) -> str:
        return f"{API_BASE}/{self.endpoint_id}/{path}"

    def submit(self, payload: dict) -> str:
        r = self._http.post(self._url("run"), json={"input": payload}, timeout=60)
        r.raise_for_status()
        return r.json()["id"]

    def status(self, job_id: str) -> dict:
        r = self._http.get(self._url(f"status/{job_id}"), timeout=60)
        r.raise_for_status()
        return r.json()

    def wait(self, job_id: str) -> dict:
        deadline = time.monotonic() + self.timeout_s
        while True:
            job = self.status(job_id)
            if job.get("status") not in _PENDING:
                return job
            if time.monotonic() > deadline:
                raise RvcError(f"Timed out after {self.timeout_s}s waiting for job {job_id} (still {job.get('status')}). "
                               "It may still be running; check it with status().")
            time.sleep(self.poll_interval_s)

    @staticmethod
    def _unwrap(job: dict) -> dict:
        status = job.get("status")
        out = job.get("output")
        if status == "COMPLETED" and isinstance(out, dict) and not out.get("error"):
            return out
        detail = (out.get("error") if isinstance(out, dict) else None) or job.get("error") or out or job
        raise RvcError(f"Job {job.get('id')} ended as {status}: {detail}")

    def call(self, payload: dict) -> dict:
        """Submit, poll to completion, return the worker's output dict (raises RvcError on failure)."""
        return self._unwrap(self.wait(self.submit(payload)))

    # ---- actions -----------------------------------------------------------------------
    def ping(self) -> dict:
        return self.call({"action": "ping"})

    def list_models(self) -> list:
        return self.call({"action": "list_models"})["models"]

    def register_model(self, model_id: str, pth_url: str, index_url: Optional[str] = None, overwrite: bool = False) -> dict:
        payload = {"action": "register_model", "model_id": model_id, "pth_url": pth_url, "overwrite": overwrite}
        if index_url:
            payload["index_url"] = index_url
        return self.call(payload)

    def delete_model(self, model_id: str) -> dict:
        return self.call({"action": "delete_model", "model_id": model_id})

    def convert(self, *, model_id: str, audio_path: Optional[str] = None, audio_url: Optional[str] = None,
                out_path: Optional[str] = None, **options) -> dict:
        """Convert one file. Options are any documented input fields (pitch, index_rate, pth_url, ...).

        If the result arrives as base64 and out_path is given, the audio is written there.
        If it arrives as a URL and out_path is given, it is downloaded there.
        """
        if (audio_path is None) == (audio_url is None):
            raise RvcError("Provide exactly one of audio_path or audio_url")
        payload = {"model_id": model_id, **options}
        if audio_url:
            payload["audio_url"] = audio_url
        else:
            data = Path(audio_path).read_bytes()
            if len(data) > 7 * 1024 * 1024:
                print(f"warning: {len(data) / 1e6:.1f} MB input as base64 may exceed RunPod's request size limit; "
                      "prefer audio_url for large files.", file=sys.stderr)
            payload["audio_b64"] = base64.b64encode(data).decode("ascii")
            payload["audio_filename"] = Path(audio_path).name
        result = self.call(payload)
        if out_path:
            if result.get("audio_b64"):
                Path(out_path).write_bytes(base64.b64decode(result["audio_b64"]))
            elif result.get("audio_url"):
                resp = requests.get(result["audio_url"], timeout=120)
                resp.raise_for_status()
                Path(out_path).write_bytes(resp.content)
        return result


def _main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--endpoint", default=os.environ.get("RUNPOD_ENDPOINT_ID"), help="endpoint id (or RUNPOD_ENDPOINT_ID)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("ping"); sub.add_parser("list")
    p = sub.add_parser("register"); p.add_argument("model_id"); p.add_argument("--pth-url", required=True)
    p.add_argument("--index-url"); p.add_argument("--overwrite", action="store_true")
    p = sub.add_parser("delete"); p.add_argument("model_id")
    p = sub.add_parser("convert"); p.add_argument("model_id"); p.add_argument("input"); p.add_argument("output")
    p.add_argument("--pitch", type=int, default=0); p.add_argument("--index-rate", type=float, default=0.75)
    p.add_argument("--protect", type=float, default=0.33); p.add_argument("--format", default="WAV")
    p.add_argument("--pth-url"); p.add_argument("--index-url")
    a = ap.parse_args(argv)
    if not a.endpoint:
        ap.error("--endpoint (or RUNPOD_ENDPOINT_ID) is required")
    c = RvcClient(a.endpoint)
    try:
        if a.cmd == "ping":
            out = c.ping()
        elif a.cmd == "list":
            out = c.list_models()
        elif a.cmd == "register":
            out = c.register_model(a.model_id, a.pth_url, a.index_url, a.overwrite)
        elif a.cmd == "delete":
            out = c.delete_model(a.model_id)
        else:
            extra = {k: v for k, v in (("pth_url", a.pth_url), ("index_url", a.index_url)) if v}
            is_url = a.input.startswith(("http://", "https://"))
            out = c.convert(model_id=a.model_id, audio_url=a.input if is_url else None,
                            audio_path=None if is_url else a.input, out_path=a.output, pitch=a.pitch,
                            index_rate=a.index_rate, protect=a.protect, export_format=a.format.upper(), **extra)
            out = {k: ("<omitted>" if k == "audio_b64" and v else v) for k, v in out.items()}
            print(f"saved -> {a.output}", file=sys.stderr)
        print(json.dumps(out, indent=2))
        return 0
    except RvcError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(_main())
