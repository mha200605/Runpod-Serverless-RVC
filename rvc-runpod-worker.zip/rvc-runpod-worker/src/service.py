"""Request handling logic, kept free of RunPod/Applio imports so it can be unit-tested."""
from __future__ import annotations

import base64
import binascii
import logging
import os
import shutil
import tempfile
import time
import traceback
from pathlib import Path
from typing import Callable, Optional

import schemas
from config import Settings
from model_store import ModelNotFound, ModelStore
from security import DownloadError, ValidationError, download_to_file
from sinks import CONTENT_TYPES, SinkError, s3_configured, select_sink

log = logging.getLogger("rvc.service")


def make_downloader(settings: Settings):
    """The single place where download limits/SSRF policy from Settings are applied."""
    def downloader(url: str, dest: Path, max_bytes: int) -> dict:
        return download_to_file(url, dest, max_bytes=max_bytes, timeout_s=settings.download_timeout_s,
                                allow_private=settings.allow_private_urls,
                                allowed_hosts=settings.allowed_url_hosts)
    return downloader


def _error(code: str, message: str) -> dict:
    # RunPod marks a job FAILED when the handler returns a dict containing a top-level "error".
    return {"status": "error", "error_code": code, "error": f"{code}: {message}"}


class Service:
    def __init__(self, settings: Settings, store: ModelStore, engine_factory: Callable[[], object]):
        self.settings = settings
        self.store = store
        self._engine_factory = engine_factory
        self._engine = None
        self._jobs_done = 0
        self._converts_done = 0
        self._started = time.time()

    @property
    def engine(self):
        if self._engine is None:
            t = time.time()
            self._engine = self._engine_factory()
            log.info("engine ready in %.1fs", time.time() - t)
        return self._engine

    # ------------------------------------------------------------------------------------
    def handle(self, raw) -> dict:
        t0 = time.time()
        try:
            action = schemas.parse_action(raw)
            if action == "convert":
                out = self._convert(schemas.parse_convert(raw, self.settings))
            elif action == "register_model":
                out = self._register(schemas.parse_register(raw))
            elif action == "list_models":
                schemas.parse_no_args(raw)
                out = {"status": "ok", "action": "list_models", "models": self.store.list()}
            elif action == "delete_model":
                req = schemas.parse_model_only(raw)
                out = {"status": "ok", "action": "delete_model", "model_id": req.model_id,
                       "deleted": self.store.delete(req.model_id)}
            else:
                schemas.parse_no_args(raw)
                out = self._ping()
            out.setdefault("timings", {})["total_s"] = round(time.time() - t0, 3)
            return out
        except (ValidationError, DownloadError, ModelNotFound, SinkError) as exc:
            return _error(exc.code, str(exc))
        except Exception as exc:  # includes ConversionError (has .code)
            log.error("job failed: %s", traceback.format_exc())
            return _error(getattr(exc, "code", "INTERNAL_ERROR"), f"{type(exc).__name__}: {exc}"[:2000])
        finally:
            self._jobs_done += 1

    # ------------------------------------------------------------------------------------
    def _download(self, url: str, dest: Path, max_bytes: int) -> dict:
        return make_downloader(self.settings)(url, dest, max_bytes)

    def _convert(self, req: schemas.ConvertRequest) -> dict:
        cold = self._converts_done == 0  # first convert on this worker process
        self._converts_done += 1
        timings = {}
        # mkdtemp's random part has no dots, so the path never contains ".wav" (Applio rewrites it).
        workdir = Path(tempfile.mkdtemp(prefix="rvcjob_"))
        try:
            t = time.time()
            paths, registered = self.store.ensure(req.model_id, req.pth_url, req.index_url,
                                                  overwrite=req.overwrite_model)
            timings["model_fetch_s"] = round(time.time() - t, 3)

            t = time.time()
            input_path = workdir / req.audio_filename
            if req.audio_url:
                self._download(req.audio_url, input_path, self.settings.max_audio_bytes)
            else:
                try:
                    data = base64.b64decode(req.audio_b64, validate=True)
                except (binascii.Error, ValueError) as exc:
                    raise ValidationError("audio_b64 is not valid base64") from exc
                if not data:
                    raise ValidationError("audio_b64 decoded to an empty file")
                if len(data) > self.settings.max_audio_bytes:
                    raise ValidationError("audio_b64 exceeds the maximum input size")
                input_path.write_bytes(data)
            timings["input_fetch_s"] = round(time.time() - t, 3)

            warnings = []
            if paths.index is None and req.index_rate > 0:
                warnings.append("No .index registered for this model; index_rate was ignored (treated as 0).")

            t = time.time()
            result = self.engine.convert(input_path=input_path, output_dir=workdir, pth=paths.pth,
                                         index=paths.index, req=req)
            timings["convert_s"] = round(time.time() - t, 3)

            t = time.time()
            sink = select_sink(req.return_mode, self.settings)
            published = sink.publish(result.path, req.export_format)
            timings["publish_s"] = round(time.time() - t, 3)

            return {
                "status": "ok",
                "action": "convert",
                "model_id": req.model_id,
                **published,
                "audio_format": req.export_format.lower(),
                "content_type": CONTENT_TYPES[req.export_format.lower()],
                "sample_rate": result.sample_rate,
                "duration_s": result.duration_s,
                "size_bytes": result.path.stat().st_size,
                "model": {
                    "registered_now": registered,
                    "has_index": paths.index is not None,
                    "index_used": paths.index is not None and req.index_rate > 0,
                    "version": result.model_version,
                },
                "worker": {"cold_start": cold, "device": result.device, "storage_mode": self.settings.storage_mode},
                "timings": timings,
                "warnings": warnings,
            }
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    def _register(self, req: schemas.RegisterRequest) -> dict:
        t = time.time()
        paths, registered = self.store.register(req.model_id, req.pth_url, req.index_url, overwrite=req.overwrite)
        return {
            "status": "ok", "action": "register_model", "model_id": req.model_id,
            "registered_now": registered, "already_present": not registered,
            "has_index": paths.index is not None, "meta": paths.meta,
            "storage_mode": self.settings.storage_mode,
            "timings": {"register_s": round(time.time() - t, 3)},
        }

    def _ping(self) -> dict:
        info = {
            "status": "ok", "action": "ping",
            "uptime_s": round(time.time() - self._started, 1),
            "jobs_handled": self._jobs_done,
            "engine_loaded": self._engine is not None,
            "storage_mode": self.settings.storage_mode,
            "models_dir": str(self.settings.models_dir),
            "models_registered": len(self.store.list()),
            "s3_configured": s3_configured(),
            "allowed_f0_methods": list(self.settings.allowed_f0_methods),
            "applio_commit": _read(self.settings.applio_dir / "PINNED_COMMIT"),
        }
        try:  # torch is only present inside the real image
            import torch

            info["torch"] = torch.__version__
            info["cuda_available"] = bool(torch.cuda.is_available())
            info["cuda_runtime"] = torch.version.cuda
            if torch.cuda.is_available():
                info["gpu"] = torch.cuda.get_device_name(0)
                info["gpu_mem_gb"] = round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1)
        except Exception as exc:  # pragma: no cover
            info["torch"] = f"unavailable ({type(exc).__name__})"
        return info


def _read(path: Path) -> Optional[str]:
    try:
        return path.read_text().strip()
    except OSError:
        return None
