"""Persistent, multi-model store.

Layout (one directory per voice, so adding a voice never touches the image):

    <models_dir>/<model_id>/model.pth
    <models_dir>/<model_id>/model.index     (optional)
    <models_dir>/<model_id>/meta.json

Files are always renamed to model.pth / model.index so user-supplied filenames can never
contain the word "trained" (see security.sanitize_model_id). Registration is staged and
swapped in with an atomic rename, so a crashed download never leaves a half-written model.
"""
from __future__ import annotations

import json
import shutil
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from security import DownloadError, ValidationError, sanitize_model_id

Downloader = Callable[[str, Path, int], dict]  # (url, dest, max_bytes) -> {"bytes","sha256","source"}


class ModelNotFound(LookupError):
    code = "MODEL_NOT_FOUND"


@dataclass(frozen=True)
class ModelPaths:
    model_id: str
    directory: Path
    pth: Path
    index: Optional[Path]
    meta: dict


def _looks_like_html(path: Path) -> bool:
    head = path.read_bytes()[:512].lstrip().lower()
    return head.startswith(b"<!doctype") or head.startswith(b"<html") or b"<html" in head[:200]


class ModelStore:
    def __init__(self, root: Path, downloader: Downloader, *, max_pth_bytes: int, max_index_bytes: int):
        self.root = Path(root)
        self._download = downloader
        self._max_pth = max_pth_bytes
        self._max_index = max_index_bytes
        self.root.mkdir(parents=True, exist_ok=True)
        if "trained" in str(self.root).lower():
            raise ValidationError(
                f"Models directory {self.root} contains 'trained'; Applio would rewrite that in index paths"
            )

    # ---- reads -------------------------------------------------------------------------
    def _dir(self, model_id: str) -> Path:
        return self.root / sanitize_model_id(model_id)

    def exists(self, model_id: str) -> bool:
        return (self._dir(model_id) / "model.pth").is_file()

    def get(self, model_id: str) -> ModelPaths:
        d = self._dir(model_id)
        pth = d / "model.pth"
        if not pth.is_file():
            raise ModelNotFound(
                f"Model {model_id!r} is not registered. Pass pth_url (and index_url) once, "
                "or call action=register_model first."
            )
        index = d / "model.index"
        meta = {}
        try:
            meta = json.loads((d / "meta.json").read_text())
        except (OSError, ValueError):
            pass
        return ModelPaths(model_id, d, pth, index if index.is_file() else None, meta)

    def list(self) -> list:
        out = []
        for d in sorted(p for p in self.root.iterdir() if p.is_dir() and not p.name.startswith(".")):
            if (d / "model.pth").is_file():
                try:
                    meta = json.loads((d / "meta.json").read_text())
                except (OSError, ValueError):
                    meta = {"model_id": d.name}
                meta["has_index"] = (d / "model.index").is_file()
                out.append(meta)
        return out

    # ---- writes ------------------------------------------------------------------------
    def register(self, model_id: str, pth_url: str, index_url: Optional[str] = None, *, overwrite: bool = False):
        """Download and install a model. Returns (ModelPaths, registered_now)."""
        mid = sanitize_model_id(model_id)
        final = self.root / mid
        if (final / "model.pth").is_file() and not overwrite:
            return self.get(mid), False

        staging = self.root / ".staging" / f"{mid}-{uuid.uuid4().hex[:8]}"
        staging.mkdir(parents=True, exist_ok=True)
        try:
            pth_info = self._download(pth_url, staging / "model.pth", self._max_pth)
            self._validate_pth(staging / "model.pth")
            meta = {
                "model_id": mid,
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "pth": {k: pth_info[k] for k in ("bytes", "sha256", "source")},
            }
            if index_url:
                idx_info = self._download(index_url, staging / "model.index", self._max_index)
                if _looks_like_html(staging / "model.index"):
                    raise DownloadError("index_url returned a web page, not an index file")
                meta["index"] = {k: idx_info[k] for k in ("bytes", "sha256", "source")}
            (staging / "meta.json").write_text(json.dumps(meta, indent=2))

            trash = None
            if final.exists():
                trash = self.root / ".trash" / f"{mid}-{uuid.uuid4().hex[:8]}"
                trash.parent.mkdir(parents=True, exist_ok=True)
                final.rename(trash)
            try:
                staging.rename(final)
            except OSError:
                # Another worker installed the same model first; keep theirs.
                if trash is not None and not final.exists():
                    trash.rename(final)
                if (final / "model.pth").is_file():
                    return self.get(mid), False
                raise
            if trash is not None:
                shutil.rmtree(trash, ignore_errors=True)
            return self.get(mid), True
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def ensure(self, model_id: str, pth_url: Optional[str], index_url: Optional[str], *, overwrite: bool = False):
        """Use the stored model; download only if missing (or overwrite requested)."""
        if self.exists(model_id) and not overwrite:
            return self.get(model_id), False
        if not pth_url:
            return self.get(model_id), False  # raises ModelNotFound with guidance
        return self.register(model_id, pth_url, index_url, overwrite=overwrite)

    def delete(self, model_id: str) -> bool:
        d = self._dir(model_id)
        if not d.exists():
            return False
        shutil.rmtree(d)
        return True

    @staticmethod
    def _validate_pth(path: Path) -> None:
        size = path.stat().st_size
        head = path.read_bytes()[:4]
        if size < 1024:
            raise DownloadError("pth_url returned a file that is too small to be an RVC model")
        if _looks_like_html(path):
            raise DownloadError("pth_url returned a web page, not a .pth file (is it a share link?)")
        # torch.save() writes a zip archive ("PK") or, for legacy files, a pickle (0x80).
        if not (head[:2] == b"PK" or head[:1] == b"\x80"):
            raise DownloadError("pth_url did not return a PyTorch checkpoint")
