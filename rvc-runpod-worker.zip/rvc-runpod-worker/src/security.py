"""Input hygiene: model-id sanitising, SSRF-safe URL checks and bounded downloads."""
from __future__ import annotations

import hashlib
import ipaddress
import os
import re
import socket
import time
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import urljoin, urlsplit


class ValidationError(ValueError):
    code = "INVALID_INPUT"


class DownloadError(RuntimeError):
    code = "DOWNLOAD_FAILED"


_MODEL_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")


def sanitize_model_id(value) -> str:
    """Model ids become directory names, so keep them boring.

    The word "trained" is rejected on purpose: Applio rewrites every occurrence of
    "trained" to "added" in the *whole index path* (infer.py, convert_audio), which would
    silently point at a file that does not exist.
    """
    if not isinstance(value, str) or not _MODEL_ID_RE.match(value):
        raise ValidationError(
            "model_id must be 1-64 chars of letters, digits, '_' or '-' and start with a letter or digit"
        )
    if "trained" in value.lower():
        raise ValidationError("model_id must not contain the word 'trained' (Applio rewrites it in index paths)")
    return value


def _blocked(ip: ipaddress._BaseAddress) -> bool:
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    return (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    )


def assert_public_http_url(url: str, *, allow_private: bool = False, allowed_hosts: Iterable[str] = ()) -> str:
    """Reject non-http(s) URLs and hosts that resolve to private/internal addresses.

    Known limit: DNS is resolved here and again by `requests`, so a hostile DNS server could
    in theory answer differently the second time (DNS rebinding). Use ALLOWED_URL_HOSTS for a
    hard allow-list if the endpoint is exposed to untrusted callers.
    """
    if not isinstance(url, str) or not url.strip():
        raise ValidationError("URL must be a non-empty string")
    parts = urlsplit(url.strip())
    if parts.scheme not in ("http", "https"):
        raise ValidationError("Only http:// and https:// URLs are allowed")
    host = (parts.hostname or "").lower()
    if not host:
        raise ValidationError("URL has no host")
    allowed = tuple(h.lower() for h in allowed_hosts)
    if allowed and host not in allowed:
        raise ValidationError(f"Host {host!r} is not in ALLOWED_URL_HOSTS")
    if allow_private:
        return url.strip()
    try:
        infos = socket.getaddrinfo(host, parts.port or (443 if parts.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise DownloadError(f"Could not resolve host {host!r}") from exc
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if _blocked(ip):
            raise ValidationError(f"URL host {host!r} resolves to a non-public address; refusing")
    return url.strip()


def redact_url(url: str) -> str:
    """Drop query/fragment (pre-signed URLs carry secrets there) before storing or logging."""
    p = urlsplit(url)
    return f"{p.scheme}://{p.netloc.split('@')[-1]}{p.path}"


def download_to_file(
    url: str,
    dest: Path,
    *,
    max_bytes: int,
    timeout_s: int = 120,
    allow_private: bool = False,
    allowed_hosts: Iterable[str] = (),
    max_redirects: int = 5,
) -> dict:
    """Stream `url` to `dest` with a size cap, a wall-clock cap and per-hop SSRF checks."""
    import requests  # imported lazily so unit tests of other modules stay light

    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".part")
    deadline = time.monotonic() + timeout_s
    current = url
    try:
        for _hop in range(max_redirects + 1):
            assert_public_http_url(current, allow_private=allow_private, allowed_hosts=allowed_hosts)
            try:
                resp = requests.get(current, stream=True, allow_redirects=False, timeout=(10, 30))
            except requests.RequestException as exc:
                raise DownloadError(f"Request failed: {type(exc).__name__}") from exc
            if 300 <= resp.status_code < 400 and resp.headers.get("Location"):
                current = urljoin(current, resp.headers["Location"])
                resp.close()
                continue
            if resp.status_code != 200:
                resp.close()
                raise DownloadError(f"HTTP {resp.status_code} from {redact_url(current)}")
            declared = resp.headers.get("Content-Length")
            if declared and declared.isdigit() and int(declared) > max_bytes:
                resp.close()
                raise DownloadError(f"File is {int(declared)} bytes; limit is {max_bytes}")
            sha = hashlib.sha256()
            total = 0
            with open(tmp, "wb") as fh:
                for chunk in resp.iter_content(chunk_size=1024 * 1024):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > max_bytes:
                        raise DownloadError(f"Download exceeded the {max_bytes} byte limit")
                    if time.monotonic() > deadline:
                        raise DownloadError(f"Download exceeded {timeout_s}s")
                    sha.update(chunk)
                    fh.write(chunk)
            resp.close()
            if total == 0:
                raise DownloadError("Downloaded file is empty")
            os.replace(tmp, dest)
            return {"bytes": total, "sha256": sha.hexdigest(), "source": redact_url(current)}
        raise DownloadError("Too many redirects")
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
