"""Thin wrapper around Applio's VoiceConverter.

Verified against Applio commit 29b4a00e4be209f9aac51cd9ccffcc632dfb2973 (rvc/infer/infer.py and
core.py were read in full). Behaviours of that code this wrapper deliberately works around:

* convert_audio() catches every exception, prints it, and returns None. We therefore capture
  stdout and verify the output file exists, and raise ConversionError with the log tail.
* get_vc() caches the loaded checkpoint by *path string*. If a model is overwritten in place
  the cache would be stale, so we compare (mtime, size) and reset `loaded_model` when it changed.
* The index path is passed through `.replace("trained", "added")` and the output path through
  `.replace(".wav", ...)`: callers must keep both words out of directory names (see security.py).
* `index_path.strip()` crashes on None, so "no index" is passed as "" with index_rate forced to 0.
* RVC v1 checkpoints load without error but are not compatible with the 768-dim ContentVec
  embedder; we reject anything that is not v2.
"""
from __future__ import annotations

import contextlib
import io
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


class ConversionError(RuntimeError):
    code = "CONVERSION_FAILED"


class _Tee(io.TextIOBase):
    def __init__(self, *streams):
        self._streams = streams

    def write(self, s):
        for st in self._streams:
            st.write(s)
        return len(s)

    def flush(self):
        for st in self._streams:
            st.flush()


@dataclass
class ConversionResult:
    path: Path
    sample_rate: int
    duration_s: float
    device: str
    model_version: str
    used_f0: bool


class RvcEngine:
    def __init__(self, applio_dir):
        applio_dir = Path(applio_dir)
        if not applio_dir.is_dir():
            raise RuntimeError(f"Applio directory not found: {applio_dir}")
        # Applio uses cwd-relative paths ("rvc/models/...") and sys.path.append(os.getcwd()).
        os.chdir(applio_dir)
        if str(applio_dir) not in sys.path:
            sys.path.insert(0, str(applio_dir))
        from rvc.infer.infer import VoiceConverter  # noqa: E402  (needs cwd set first)

        self._vc = VoiceConverter()
        self._loaded_fp: Optional[tuple] = None

    # -------------------------------------------------------------------------------------
    @property
    def device(self) -> str:
        return str(getattr(self._vc.config, "device", "unknown"))

    def warmup(self, embedder_model: str = "contentvec") -> None:
        """Load the ContentVec embedder once at worker start so first jobs are not slower."""
        self._vc.load_hubert(embedder_model)
        self._vc.last_embedder_model = embedder_model

    def _prepare_model(self, pth: Path, sid: int) -> None:
        st = pth.stat()
        fp = (str(pth), st.st_mtime_ns, st.st_size)
        if self._loaded_fp is not None and self._loaded_fp != fp and self._loaded_fp[0] == fp[0]:
            self._vc.loaded_model = None  # same path, new contents -> force reload
        self._vc.get_vc(str(pth), sid)
        if self._vc.cpt is None or self._vc.net_g is None:
            raise ConversionError("Model checkpoint could not be loaded")
        self._loaded_fp = fp
        if self._vc.version != "v2":
            raise ConversionError(
                f"This checkpoint is RVC {self._vc.version}; only RVC v2 models are supported"
            )

    def convert(self, *, input_path: Path, output_dir: Path, pth: Path, index: Optional[Path], req) -> ConversionResult:
        for p in (pth, index):
            if p is not None and "trained" in str(p).lower():
                raise ConversionError("Model path contains 'trained', which Applio rewrites in index paths")
        out_wav = Path(output_dir) / "out.wav"
        final = Path(output_dir) / f"out.{req.export_format.lower()}"
        index_path = str(index) if index is not None else ""
        index_rate = req.index_rate if index is not None else 0.0

        log = io.StringIO()
        started = time.time()
        with contextlib.redirect_stdout(_Tee(sys.stdout, log)):
            try:
                self._prepare_model(Path(pth), req.sid)
                self._vc.convert_audio(
                    audio_input_path=str(input_path),
                    audio_output_path=str(out_wav),
                    model_path=str(pth),
                    index_path=index_path,
                    pitch=req.pitch,
                    f0_method=req.f0_method,
                    index_rate=index_rate,
                    volume_envelope=req.volume_envelope,
                    protect=req.protect,
                    split_audio=req.split_audio,
                    f0_autotune=req.f0_autotune,
                    f0_autotune_strength=req.f0_autotune_strength,
                    filter_radius=req.filter_radius,
                    embedder_model=req.embedder_model,
                    clean_audio=req.clean_audio,
                    clean_strength=req.clean_strength,
                    export_format=req.export_format,
                    sid=req.sid,
                    # Same extra kwargs Applio's own core.py passes (consumed by load_audio_infer).
                    formant_shifting=False,
                    formant_qfrency=1.0,
                    formant_timbre=1.0,
                    post_process=False,
                )
            except ConversionError:
                raise
            except Exception as exc:
                raise ConversionError(f"{type(exc).__name__}: {exc}") from exc

        if not final.is_file() or final.stat().st_size == 0:
            tail = log.getvalue().strip().splitlines()[-12:]
            raise ConversionError(
                "Applio did not produce an output file. Log tail: " + " | ".join(tail)[-1500:]
            )

        import soundfile as sf  # present in the Applio environment

        info = sf.info(str(final))
        return ConversionResult(
            path=final,
            sample_rate=int(info.samplerate),
            duration_s=round(float(info.duration), 3),
            device=self.device,
            model_version=str(self._vc.version),
            used_f0=bool(self._vc.use_f0),
        )
