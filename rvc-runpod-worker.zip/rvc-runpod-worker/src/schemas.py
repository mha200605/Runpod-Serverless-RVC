"""Request parsing/validation. Strict on purpose: unknown fields are rejected so typos
(e.g. "index_rat") fail loudly instead of silently using defaults."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from config import Settings
from security import ValidationError, sanitize_model_id

ACTIONS = ("convert", "register_model", "list_models", "delete_model", "ping")
EXPORT_FORMATS = ("WAV", "MP3", "FLAC", "OGG")  # M4A is in Applio's CLI but soundfile cannot write it
RETURN_MODES = ("auto", "base64", "url")
EMBEDDERS = ("contentvec",)  # other embedders need extra weights that are not baked into the image
AUDIO_EXTS = (".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac", ".opus", ".webm", ".mp4")

_CONVERT_KEYS = {
    "action", "model_id", "audio_url", "audio_b64", "audio_filename", "pth_url", "index_url",
    "overwrite_model", "pitch", "f0_method", "filter_radius", "f0_autotune", "f0_autotune_strength",
    "index_rate", "protect", "volume_envelope", "split_audio", "clean_audio", "clean_strength",
    "export_format", "embedder_model", "sid", "return_mode",
}
_REGISTER_KEYS = {"action", "model_id", "pth_url", "index_url", "overwrite"}
_MODEL_ONLY_KEYS = {"action", "model_id"}
_NO_KEYS = {"action"}


@dataclass(frozen=True)
class ConvertRequest:
    model_id: str
    audio_url: Optional[str]
    audio_b64: Optional[str]
    audio_filename: str
    pth_url: Optional[str]
    index_url: Optional[str]
    overwrite_model: bool
    pitch: int
    f0_method: str
    filter_radius: int
    f0_autotune: bool
    f0_autotune_strength: float
    index_rate: float
    protect: float
    volume_envelope: float
    split_audio: bool
    clean_audio: bool
    clean_strength: float
    export_format: str
    embedder_model: str
    sid: int
    return_mode: str


@dataclass(frozen=True)
class RegisterRequest:
    model_id: str
    pth_url: str
    index_url: Optional[str]
    overwrite: bool


@dataclass(frozen=True)
class ModelRequest:
    model_id: str


def _reject_unknown(raw: dict, allowed: set) -> None:
    extra = sorted(set(raw) - allowed)
    if extra:
        raise ValidationError(f"Unknown field(s): {', '.join(extra)}")


def _num(raw: dict, key: str, default, lo, hi, *, integer: bool = False):
    value = raw.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValidationError(f"{key} must be a number")
    if integer and (isinstance(value, float) and not value.is_integer()):
        raise ValidationError(f"{key} must be an integer")
    value = int(value) if integer else float(value)
    if not (lo <= value <= hi):
        raise ValidationError(f"{key} must be between {lo} and {hi}")
    return value


def _flag(raw: dict, key: str, default: bool) -> bool:
    value = raw.get(key, default)
    if not isinstance(value, bool):
        raise ValidationError(f"{key} must be true or false")
    return value


def _url(raw: dict, key: str, *, required: bool = False) -> Optional[str]:
    value = raw.get(key)
    if value is None or value == "":
        if required:
            raise ValidationError(f"{key} is required")
        return None
    if not isinstance(value, str) or len(value) > 4096:
        raise ValidationError(f"{key} must be a URL string (max 4096 chars)")
    if not value.lower().startswith(("http://", "https://")):
        raise ValidationError(f"{key} must start with http:// or https://")
    return value


def _choice(raw: dict, key: str, default: str, choices, *, upper: bool = False, lower: bool = False) -> str:
    value = raw.get(key, default)
    if not isinstance(value, str):
        raise ValidationError(f"{key} must be a string")
    if upper:
        value = value.upper()
    if lower:
        value = value.lower()
    if value not in choices:
        raise ValidationError(f"{key} must be one of: {', '.join(choices)}")
    return value


def parse_action(raw: Any) -> str:
    if not isinstance(raw, dict):
        raise ValidationError("input must be a JSON object")
    action = raw.get("action", "convert")
    if action not in ACTIONS:
        raise ValidationError(f"action must be one of: {', '.join(ACTIONS)}")
    return action


def parse_convert(raw: dict, settings: Settings) -> ConvertRequest:
    _reject_unknown(raw, _CONVERT_KEYS)
    if "model_id" not in raw:
        raise ValidationError("model_id is required")
    audio_url = _url(raw, "audio_url")
    audio_b64 = raw.get("audio_b64")
    if audio_b64 in ("", None):
        audio_b64 = None
    elif not isinstance(audio_b64, str):
        raise ValidationError("audio_b64 must be a base64 string")
    if (audio_url is None) == (audio_b64 is None):
        raise ValidationError("Provide exactly one of audio_url or audio_b64")
    filename = raw.get("audio_filename", "input.wav")
    if not isinstance(filename, str):
        raise ValidationError("audio_filename must be a string")
    ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ".wav"
    if ext not in AUDIO_EXTS:
        ext = ".wav"
    return ConvertRequest(
        model_id=sanitize_model_id(raw["model_id"]),
        audio_url=audio_url,
        audio_b64=audio_b64,
        audio_filename="input" + ext,
        pth_url=_url(raw, "pth_url"),
        index_url=_url(raw, "index_url"),
        overwrite_model=_flag(raw, "overwrite_model", False),
        pitch=_num(raw, "pitch", 0, -24, 24, integer=True),
        f0_method=_choice(raw, "f0_method", "rmvpe", settings.allowed_f0_methods, lower=True),
        filter_radius=_num(raw, "filter_radius", 3, 0, 10, integer=True),
        f0_autotune=_flag(raw, "f0_autotune", False),
        f0_autotune_strength=_num(raw, "f0_autotune_strength", 1.0, 0.0, 1.0),
        index_rate=_num(raw, "index_rate", 0.75, 0.0, 1.0),
        protect=_num(raw, "protect", 0.33, 0.0, 0.5),
        volume_envelope=_num(raw, "volume_envelope", 1.0, 0.0, 1.0),
        split_audio=_flag(raw, "split_audio", False),
        clean_audio=_flag(raw, "clean_audio", False),
        clean_strength=_num(raw, "clean_strength", 0.7, 0.0, 1.0),
        export_format=_choice(raw, "export_format", "WAV", EXPORT_FORMATS, upper=True),
        embedder_model=_choice(raw, "embedder_model", "contentvec", EMBEDDERS, lower=True),
        sid=_num(raw, "sid", 0, 0, 1000, integer=True),
        return_mode=_choice(raw, "return_mode", settings.default_return_mode, RETURN_MODES, lower=True),
    )


def parse_register(raw: dict) -> RegisterRequest:
    _reject_unknown(raw, _REGISTER_KEYS)
    if "model_id" not in raw:
        raise ValidationError("model_id is required")
    return RegisterRequest(
        model_id=sanitize_model_id(raw["model_id"]),
        pth_url=_url(raw, "pth_url", required=True),
        index_url=_url(raw, "index_url"),
        overwrite=_flag(raw, "overwrite", False),
    )


def parse_model_only(raw: dict) -> ModelRequest:
    _reject_unknown(raw, _MODEL_ONLY_KEYS)
    if "model_id" not in raw:
        raise ValidationError("model_id is required")
    return ModelRequest(model_id=sanitize_model_id(raw["model_id"]))


def parse_no_args(raw: dict) -> None:
    _reject_unknown(raw, _NO_KEYS)
