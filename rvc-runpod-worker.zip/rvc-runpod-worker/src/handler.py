"""RunPod Serverless entrypoint.  Run with:  cd /opt/applio && python -u /app/handler.py"""
from __future__ import annotations

import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import load_settings  # noqa: E402
from model_store import ModelStore  # noqa: E402
from service import Service, make_downloader  # noqa: E402

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("rvc.handler")

_service = None


def build_service() -> Service:
    settings = load_settings()

    store = ModelStore(settings.models_dir, make_downloader(settings),
                       max_pth_bytes=settings.max_pth_bytes, max_index_bytes=settings.max_index_bytes)

    def engine_factory():
        from rvc_engine import RvcEngine  # heavy imports happen here, not at module import

        engine = RvcEngine(settings.applio_dir)
        try:
            engine.warmup("contentvec")
        except Exception:
            log.exception("embedder warmup failed; it will load on first request instead")
        return engine

    log.info("storage_mode=%s models_dir=%s", settings.storage_mode, settings.models_dir)
    return Service(settings, store, engine_factory)


def handler(job):
    global _service
    if _service is None:
        _service = build_service()
    return _service.handle((job or {}).get("input"))


def main():
    global _service
    import runpod  # imported here so tests can import this module without the SDK

    _service = build_service()
    if os.environ.get("PRELOAD_ENGINE", "1") == "1":
        try:
            _ = _service.engine
        except Exception:
            log.exception("engine preload failed; will retry lazily on the first convert request")
    runpod.serverless.start({"handler": handler})


if __name__ == "__main__":
    main()
