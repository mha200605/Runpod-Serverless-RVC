"""Runtime configuration for the RVC worker. Everything comes from environment variables
so the same image can run with or without a network volume and with or without S3."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Optional

MB = 1024 * 1024


def _int(env: Mapping[str, str], name: str, default: int) -> int:
    raw = env.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"Environment variable {name} must be an integer, got {raw!r}") from exc


def _bool(env: Mapping[str, str], name: str, default: bool) -> bool:
    raw = env.get(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _csv(env: Mapping[str, str], name: str) -> tuple:
    raw = env.get(name, "")
    return tuple(p.strip().lower() for p in raw.split(",") if p.strip())


def resolve_models_dir(env: Mapping[str, str]) -> tuple[Path, str]:
    """Pick where voice models live.

    1. RVC_MODELS_DIR if set (explicit).
    2. <volume>/rvc/models if a RunPod network volume is mounted (persistent).
    3. /tmp/rvc_models otherwise (ephemeral: wiped whenever the worker is recycled).
    """
    explicit = env.get("RVC_MODELS_DIR", "").strip()
    if explicit:
        return Path(explicit), "explicit"
    volume = Path(env.get("RUNPOD_VOLUME_PATH", "/runpod-volume"))
    if volume.is_dir() and os.access(volume, os.W_OK):
        return volume / "rvc" / "models", "network-volume"
    return Path("/tmp/rvc_models"), "ephemeral"


@dataclass(frozen=True)
class Settings:
    applio_dir: Path
    models_dir: Path
    storage_mode: str  # explicit | network-volume | ephemeral
    max_audio_bytes: int
    max_pth_bytes: int
    max_index_bytes: int
    download_timeout_s: int
    max_inline_output_bytes: int
    allow_private_urls: bool
    allowed_url_hosts: tuple
    default_return_mode: str  # auto | base64 | url
    allowed_f0_methods: tuple
    s3_presign_ttl_s: int


def load_settings(env: Optional[Mapping[str, str]] = None) -> Settings:
    env = os.environ if env is None else env
    models_dir, mode = resolve_models_dir(env)
    default_mode = env.get("DEFAULT_RETURN_MODE", "auto").strip().lower() or "auto"
    if default_mode not in {"auto", "base64", "url"}:
        raise ValueError("DEFAULT_RETURN_MODE must be one of auto, base64, url")
    return Settings(
        applio_dir=Path(env.get("APPLIO_DIR", "/opt/applio")),
        models_dir=models_dir,
        storage_mode=mode,
        max_audio_bytes=_int(env, "MAX_AUDIO_MB", 100) * MB,
        max_pth_bytes=_int(env, "MAX_PTH_MB", 512) * MB,
        max_index_bytes=_int(env, "MAX_INDEX_MB", 1024) * MB,
        download_timeout_s=_int(env, "DOWNLOAD_TIMEOUT_S", 120),
        max_inline_output_bytes=_int(env, "MAX_INLINE_OUTPUT_MB", 7) * MB,
        allow_private_urls=_bool(env, "ALLOW_PRIVATE_URLS", False),
        allowed_url_hosts=_csv(env, "ALLOWED_URL_HOSTS"),
        default_return_mode=default_mode,
        # Only rmvpe is exercised by this project. Other methods exist in Applio but are
        # untested here (some need extra weights). Extend via env once verified.
        allowed_f0_methods=_csv(env, "ALLOWED_F0_METHODS") or ("rmvpe",),
        s3_presign_ttl_s=_int(env, "S3_PRESIGN_TTL_S", 3600),
    )
