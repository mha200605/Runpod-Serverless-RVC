"""Output delivery. The API always returns the same fields (`audio_b64`, `audio_url`);
which one is filled depends on the sink, so switching from base64 to S3-compatible storage
is a configuration change, not an API change."""
from __future__ import annotations

import base64
import os
import time
import uuid
from pathlib import Path
from typing import Mapping, Optional

from config import Settings

CONTENT_TYPES = {"wav": "audio/wav", "mp3": "audio/mpeg", "flac": "audio/flac", "ogg": "audio/ogg"}


class SinkError(RuntimeError):
    code = "OUTPUT_FAILED"


class Base64Sink:
    name = "base64"

    def __init__(self, max_bytes: int):
        self.max_bytes = max_bytes

    def publish(self, path: Path, fmt: str) -> dict:
        size = Path(path).stat().st_size
        if size > self.max_bytes:
            raise SinkError(
                f"Output is {size / 1e6:.1f} MB, above the {self.max_bytes / 1e6:.0f} MB inline limit. "
                "Use a shorter clip, export_format=MP3/FLAC/OGG, or configure S3-compatible storage "
                "and set return_mode=url."
            )
        data = base64.b64encode(Path(path).read_bytes()).decode("ascii")
        return {"delivery": "base64", "audio_b64": data, "audio_url": None, "expires_in_s": None}


_S3_REQUIRED = ("S3_BUCKET", "S3_ACCESS_KEY_ID", "S3_SECRET_ACCESS_KEY")


def s3_configured(env: Optional[Mapping[str, str]] = None) -> bool:
    env = os.environ if env is None else env
    return all(env.get(k) for k in _S3_REQUIRED)


class S3Sink:
    """Any S3-compatible store (AWS S3, Cloudflare R2, Backblaze B2, MinIO).

    Env: S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, optional S3_ENDPOINT_URL,
    S3_REGION (default "auto"), S3_PREFIX (default "rvc-output/"), S3_PRESIGN_TTL_S.
    NOTE: written but NOT exercised in this project's first test (no bucket yet).
    """

    name = "s3"

    def __init__(self, ttl_s: int, env: Optional[Mapping[str, str]] = None):
        env = os.environ if env is None else env
        try:
            import boto3
            from botocore.config import Config as BotoConfig
        except ImportError as exc:  # pragma: no cover
            raise SinkError("boto3 is not installed in this image") from exc
        self.bucket = env["S3_BUCKET"]
        self.prefix = env.get("S3_PREFIX", "rvc-output/")
        self.ttl_s = ttl_s
        self._client = boto3.client(
            "s3",
            endpoint_url=env.get("S3_ENDPOINT_URL") or None,
            region_name=env.get("S3_REGION", "auto"),
            aws_access_key_id=env["S3_ACCESS_KEY_ID"],
            aws_secret_access_key=env["S3_SECRET_ACCESS_KEY"],
            config=BotoConfig(signature_version="s3v4", retries={"max_attempts": 3}),
        )

    def publish(self, path: Path, fmt: str) -> dict:
        key = f"{self.prefix}{time.strftime('%Y/%m/%d', time.gmtime())}/{uuid.uuid4().hex}.{fmt.lower()}"
        try:
            self._client.upload_file(
                str(path), self.bucket, key, ExtraArgs={"ContentType": CONTENT_TYPES.get(fmt.lower(), "application/octet-stream")}
            )
            url = self._client.generate_presigned_url(
                "get_object", Params={"Bucket": self.bucket, "Key": key}, ExpiresIn=self.ttl_s
            )
        except Exception as exc:  # boto raises many types
            raise SinkError(f"Upload failed: {type(exc).__name__}") from exc
        return {"delivery": "url", "audio_b64": None, "audio_url": url, "expires_in_s": self.ttl_s}


def select_sink(return_mode: str, settings: Settings, env: Optional[Mapping[str, str]] = None):
    configured = s3_configured(env)
    if return_mode == "url" and not configured:
        raise SinkError("return_mode=url requested but S3 storage is not configured on this endpoint")
    if return_mode == "url" or (return_mode == "auto" and configured):
        return S3Sink(settings.s3_presign_ttl_s, env)
    return Base64Sink(settings.max_inline_output_bytes)
