"""Build-time smoke test (CPU only): the inference class imports, constructs, and the embedder loads."""
import os
import sys

APPLIO = os.environ.get("APPLIO_DIR", "/opt/applio")
os.chdir(APPLIO)
sys.path.insert(0, APPLIO)

from rvc.infer.infer import VoiceConverter  # noqa: E402

vc = VoiceConverter()
print("VoiceConverter constructed; device =", vc.config.device, "| is_half =", vc.config.is_half)
vc.load_hubert("contentvec")
print("contentvec embedder loaded OK")
import soundfile, runpod  # noqa: E402,F401  (worker imports)

print("smoke test OK")
