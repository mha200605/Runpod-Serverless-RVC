"""Build-time: download Applio's base models and prove the files we need are present."""
import glob
import os
import sys

APPLIO = os.environ.get("APPLIO_DIR", "/opt/applio")
os.chdir(APPLIO)  # Applio uses cwd-relative paths
sys.path.insert(0, APPLIO)

# Import path and 6-bool signature verified in core.py (run_prerequisites_script) at the pinned commit:
# (pretraineds_v1_f0, pretraineds_v1_nof0, pretraineds_v2_f0, pretraineds_v2_nof0, models, exe)
from rvc.lib.tools.prerequisites_download import prequisites_download_pipeline  # noqa: E402

prequisites_download_pipeline(False, False, False, False, True, False)

files = {p: os.path.getsize(p) for p in glob.glob("rvc/models/**/*", recursive=True) if os.path.isfile(p)}
print("---- rvc/models after prerequisites ----")
for path, size in sorted(files.items()):
    print(f"{size:>14,}  {path}")

has_rmvpe = any(os.path.basename(p) == "rmvpe.pt" for p in files)
has_contentvec = any("contentvec" in p.lower() for p in files)
if not (has_rmvpe and has_contentvec):
    sys.exit(f"ERROR: expected rmvpe.pt (found={has_rmvpe}) and a contentvec embedder (found={has_contentvec}). "
             "Paths above show what was actually downloaded; adjust scripts/build_prereqs.py accordingly.")
print("prerequisites OK")
